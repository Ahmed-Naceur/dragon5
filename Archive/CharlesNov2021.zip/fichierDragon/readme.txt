Voici les fichiers de ma version officieuse de DRAGON5.

Je liste ici les modifications qui sont apportées à chaque fichier et leur qualité sur 
l'échelle (--:médiocre,-,+,++:Implémentation quasi définitive).

---------------------------------------------------------------------------------------------
Dans le dossier src/ de DRAGON/ :
---------------------------------------------------------------------------------------------

FMAC01.f :    (--) J'ai procédé à une petite permutation des lettres associés à proton et 
                   positron pour permettre la lecture des fichiers avec électron. Temporaire
                   seulement
              (-)  J'ai appliqué une correction pour la lecture des frontières énergétiques
                   et des stopping power associés.

ASMDRV.f :    (++) Transfert de E_{cutoff} dans une macrolib
              (++) Transfert du terme T=alpha/2 dans une macrolib seulement si au moins une
                   valeur non-nulle

SNFLUX.f :    (++) Récupération des valeurs de E_{cutoff} et de T=alpha/2
              (+) Calcul de l'énergie sous le cutoff (++ pour le 1D, j'ai pas encore testé en 2D/3D)
              (++) Ajout de DCUTOFF comme argument de SNFLUX.f
              (+)  Transfert de alpha à la subroutine SNFP1P.f

SNFP1P.f :    (+)  Traitement direct du terme alpha
              (--) Source monodirectionnelle implémenté directement dans cette sous-routine,
                   à décommenter pour utiliser. Problème oscillatoire avec celle-ci à bas
                   nombre de groupe. Normalisation non fonctionnelle, donc manuelle seulement.

SNFT1P.f :    (--) Source monodirectionnelle implémenté directement dans cette sous-routine,
                   à décommenter pour utiliser.Normalisation non fonctionnelle, donc manuelle
                   seulement.

SNF.f :       (++) Ajout de DCUTOFF comme argument

DOORFVR.f :   (++) Ajout de DCUTOFF comme argument

FLU2DR.f :    (++) Transfert de DCUTOFF dans une macrolib

HEADRV.f :    (++) Ajout du cutoff au calcul de l'énergie de déposition

---------------------------------------------------------------------------------------------
Dans le dossier src/ de Trivac/ :
---------------------------------------------------------------------------------------------

OUTDRV.f :    (++) Transfert de DCUTOFF d'une macrolib à une autre


